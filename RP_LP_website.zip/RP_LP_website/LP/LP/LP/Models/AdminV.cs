﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LP.Models
{
    public class AdminV
    {
        public int LicenseId { get; set; }

        [Required(ErrorMessage = "License Plate cannot be empty!")]
        public string LicensePlate { get; set; }

        [Required(ErrorMessage = "Name cannot be empty!")]
        public string FullName { get; set; }
        public int StaffID { get; set; }
        public int CarparkNo { get; set; }
        public string Email { get; set; }
        public string CarModel { get; set; }
        public string CarMake { get; set; }
        public string Remarks { get; set; }
    }
}
