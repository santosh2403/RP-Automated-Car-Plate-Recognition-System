﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace LP.Models
{ 

        public class AdminUser
        {
            [Required(ErrorMessage = "Please enter User ID")]
            public string UserName { get; set; }

            [Required(ErrorMessage = "Please enter Password")]
            [DataType(DataType.Password)]
            public string Password { get; set; }
            public bool RememberMe { get; set; }
    }
    }


