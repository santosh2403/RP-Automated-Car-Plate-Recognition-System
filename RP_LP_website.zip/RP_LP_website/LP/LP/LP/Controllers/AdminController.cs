﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using LP.Models;
using System;
using System.Data;
using System.Collections.Generic;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LP.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult Index()
        {
            List<AdminV> model = DBUtl.GetList<AdminV>(@"SELECT * FROM StaffCar");
            return View(model);
        }
        public IActionResult Carpark()
        {
            List<CPTypes> model1 = DBUtl.GetList<CPTypes>(@"SELECT * FROM Carpark");
            return View(model1);
        }

        public IActionResult Admin()
        {
            string sql = "SELECT * FROM StaffCar";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        #region "Admin Add"
        public IActionResult AdminAdd()
        {
            return View();
        }

        public IActionResult AdminAddPost()
        {
            IFormCollection form = HttpContext.Request.Form;
            string LicenseId = form["LicenseId"].ToString().Trim();
            string LicensePlate = form["LicensePlate"].ToString().Trim();
            string FullName = form["FullName"].ToString().Trim();
            string StaffID = form["StaffID"].ToString().Trim();
            string CarparkNo = form["CarparkNo"].ToString().Trim();
            string Email = form["Email"].ToString().Trim();
            string CarModel = form["CarModel"].ToString().Trim();
            string CarMake = form["CarMake"].ToString().Trim();
            string Remarks = form["Remarks"].ToString().Trim();

            if (ValidUtl.CheckIfEmpty(LicenseId, LicensePlate, FullName, StaffID, CarparkNo, Email, CarModel, CarMake, Remarks))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("AdminAdd");
            }

            if (!LicenseId.IsInteger())
            {
                ViewData["Message"] = "License ID must be an integer";
                ViewData["MsgType"] = "warning";
                return View("AdminAdd");
            }

            if (!StaffID.IsInteger())
            {
                ViewData["Message"] = "Staff ID must be an integer";
                ViewData["MsgType"] = "warning";
                return View("AdminAdd");
            }


            if (!CarparkNo.IsInteger())
            {
                ViewData["Message"] = "Carpark Number must be an integer";
                ViewData["MsgType"] = "warning";
                return View("AdminAdd");
            }

            string sql = @"SET IDENTITY_INSERT StaffCar ON 
                        INSERT INTO StaffCar(LicenseId, LicensePlate, FullName, StaffID, CarparkNo, Email, CarModel, CarMake, Remarks) 
                        VALUES({0}, '{1}', '{2}', {3}, {4}, '{5}', '{6}', '{7}', '{8}')";
            string insert = String.Format(sql, LicenseId, LicensePlate, FullName, StaffID, CarparkNo, Email, CarModel, CarMake, Remarks);
            int res = DBUtl.ExecSQL(insert);
            if (res == 1)
            {
                TempData["Message"] = "Vehicle Added";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Index");
        }
        #endregion

        #region "Admin Edit"
        [HttpGet]
        public IActionResult AdminEdit(int id)
        {

            string updatesql = @"SELECT * FROM StaffCar
                               WHERE LicenseId = {0}";
            List<AdminV> vehicles = DBUtl.GetList<AdminV>(updatesql, id);
            if (vehicles.Count == 1)
            {
                return View(vehicles[0]);
            }
            else
            {
                TempData["Message"] = "Vehicles not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Index");
            }

        }


        [HttpPost]
        public IActionResult AdminEdit(AdminV ord)
        {
            if (ValidUtl.CheckIfEmpty(ord.LicensePlate, ord.FullName, ord.Email, ord.CarModel, ord.CarMake, ord.Remarks))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("AdminEdit");
            }

                string edit =
                   @"UPDATE StaffCar
                    SET LicensePlate ='{1}', FullName='{2}',StaffID={3}, CarparkNo={4}, Email='{5}', CarModel='{6}', CarMake='{7}', Remarks='{8}' WHERE LicenseId={0}";
                
                int res = DBUtl.ExecSQL(edit, ord.LicenseId, ord.LicensePlate, ord.FullName, ord.StaffID, ord.CarparkNo, ord.Email, ord.CarModel, ord.CarMake, ord.Remarks);
                if (res == 1)
                {
                    TempData["Message"] = "Vehicles Updated";
                    TempData["MsgType"] = "success";

                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("Index");
            }

        
        #endregion

        #region "Admin Delete"
        public IActionResult AdminDelete(String id)
        {
            string sql = "DELETE FROM StaffCar WHERE LicenseId={0}";
            string delete = String.Format(sql, id);
            int res = DBUtl.ExecSQL(delete);
            if (res == 1)
            {
                TempData["Message"] = "Vehicle Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Index");
        }
        #endregion
    }
}
