﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Security.Claims;
using LP.Models;
using Microsoft.AspNetCore.Authorization;

namespace LP.Controllers
{
    public class LoginController : Controller
    {
        [Authorize]
        public IActionResult Logoff(string returnUrl = null)
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Login", "Login");
        }

        [AllowAnonymous]
        public IActionResult Login(string returnUrl = null)
        {
            TempData["ReturnUrl"] = returnUrl;
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login(AdminUser user)
        {
            if (!AuthenticateUser(user.UserName, user.Password,
                                  out ClaimsPrincipal principal))
            {
                ViewData["Message"] = "Incorrect Username or Password";
                return View();
            }
            else
            {
                HttpContext.SignInAsync(
                   CookieAuthenticationDefaults.AuthenticationScheme,
                   principal,
                   new AuthenticationProperties
                   {
                      IsPersistent = false // <--- Here
                   });

               

                return RedirectToAction("Index", "Admin");
            }
        }

        [AllowAnonymous]
        public IActionResult Forbidden()
        {
            return View();                                    
        }     

        private bool AuthenticateUser(string uName, string pw,
                                         out ClaimsPrincipal principal)
        {
            principal = null;


            string sql = @"SELECT * FROM Admin WHERE UserName = '{0}' AND UserPw = HASHBYTES('SHA1', '{1}')";

            // TODO: L09 Task 1 - Login
            DataTable ds = DBUtl.GetTable(sql, uName, pw);
            if (ds.Rows.Count == 1)
            {
                principal =
                   new ClaimsPrincipal(
                      new ClaimsIdentity(
                         new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, uName),
                        new Claim(ClaimTypes.Name, ds.Rows[0]["UserName"].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0]["UserPw"].ToString())
                         },
                         CookieAuthenticationDefaults.AuthenticationScheme));
                return true;
            }
            return false;
        }

    }
}